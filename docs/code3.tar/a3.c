
/* Derived from scene.c in the The OpenGL Programming Guide */
/* Keyboard and mouse rotation taken from Swiftless Tutorials #23 Part 2 */
/* http://www.swiftless.com/tutorials/opengl/camera2.html */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "graphics.h"


extern void gradphicsInit(int *, char **);
extern void setLightPosition(GLfloat, GLfloat, GLfloat);
extern GLfloat* getLightPosition();

extern void setViewPosition(float, float, float);
extern void getViewPosition(float *, float *, float *);
extern void getOldViewPosition(float *, float *, float *);
extern void getViewOrientation(float *, float *, float *);

extern int addDisplayList(int, int, int);

extern void createMob(int, float, float, float, float);
extern void setMobPosition(int, float, float, float, float);
extern void hideMob(int);
extern void showMob(int);

	/* flag which is set to 1 when flying behaviour is desired */
extern int flycontrol;
	/* flag used to indicate that the test world should be used */
extern int testWorld;
	/* list and count of polygons to be displayed, set during culling */
extern int displayList[MAX_DISPLAY_LIST][3];
extern int displayCount;
	/* flag to print out frames per second */
extern int fps;
	/* flag to indicate removal of cube the viewer is facing */
extern int dig;


/***********************/


	/* -performs collision detection and response */
	/*  sets new xyz  to position of the viewpoint after collision */
	/* -implements gravity by updating y position of viewpoint */
	/* note that the world coordinates will be the negative value of
	   the array indices */
void collisionResponse() {

	/* your code goes here */

}




	/* background process, it is called when there are no other events */
	/* -gravity is also implemented here, duplicate of collisionResponse */
	/* -for assignment 3, mob control and digging goes here */
void update() {

	/* your code goes here */


	/* sample use of the dig flag, it is set equal to 1 when the user */
	/*  presses the space bar, you need to reset it to 0 */
   if (dig == 1) {
      printf("dig\n");
      dig = 0;
   }
	/* sample code showing the position and rotation controls */
	/* for the mobs, this can be removed */
   if (testWorld) {
	/* sample of rotation and positioning of mob */
	/* coordinates for mob 0 */
   static float mob0x = 50.0, mob0y = 25.0, mob0z = 52.0;
   static float mob0ry = 0.0;
   static int increasingmob0 = 1;
	/* coordinates for mob 1 */
   static float mob1x = 50.0, mob1y = 25.0, mob1z = 52.0;
   static float mob1ry = 0.0;
   static int increasingmob1 = 1;

	/* move mob 0 and rotate */
	/* set mob 0 position */
      setMobPosition(0, mob0x, mob0y, mob0z, mob0ry);

	/* move mob 0 in the x axis */
      if (increasingmob0 == 1)
         mob0x += 0.2;
      else 
         mob0x -= 0.2;
      if (mob0x > 50) increasingmob0 = 0;
      if (mob0x < 30) increasingmob0 = 1;

	/* rotate mob 0 around the y axis */
      mob0ry += 1.0;
      if (mob0ry > 360.0) mob0ry -= 360.0;

	/* move mob 1 and rotate */
      setMobPosition(1, mob1x, mob1y, mob1z, mob1ry);

	/* move mob 1 in the z axis */
	/* when mob is moving away it is visible, when moving back it */
	/* is hidden */
      if (increasingmob1 == 1) {
         mob1z += 0.2;
         showMob(1);
      } else {
         mob1z -= 0.2;
         hideMob(1);
      }
      if (mob1z > 72) increasingmob1 = 0;
      if (mob1z < 52) increasingmob1 = 1;

	/* rotate mob 1 around the y axis */
      mob1ry += 1.0;
      if (mob1ry > 360.0) mob1ry -= 360.0;
   }

}


	/* determines which cubes are to be drawn and puts them into */
	/* the displayList  */
	/* write your cube culling code here */
void buildDisplayList() {
        /* used to calculate frames per second */
static int frame=0, time, timebase=0;



	/* frame per second calculation */
	/* don't change the following routine */
	/* http://www.lighthouse3d.com/opengl/glut/index.php?fps */
   if (fps == 1) {
      frame++;
      time=glutGet(GLUT_ELAPSED_TIME);
      if (time - timebase > 1000) {
         printf("FPS:%4.2f\n", frame*1000.0/(time-timebase));
         timebase = time;		
         frame = 0;
       }
   }

	/* redraw the screen at the end of the update */
   glutPostRedisplay();
}



int main(int argc, char** argv)
{
int i, j, k;
	/* Initialize the graphics system */
   gradphicsInit(&argc, argv);

	/* the first part of this if statement builds a sample */
	/* world which will be used for testing */
	/* DO NOT remove this code. It will be used to test the timing */
	/* of your culling solution. Put your code in the else statment below */
   if (testWorld == 1) {
	/* initialize world to empty */
      for(i=0; i<100; i++)
         for(j=0; j<50; j++)
            for(k=0; k<100; k++)
               world[i][j][k] = 0;
	
	/* some sample objects */
	/* create some green and blue cubes */
      world[50][25][50] = 1;
      world[49][25][50] = 1;
      world[49][26][50] = 1;
      world[52][25][52] = 2;
      world[52][26][52] = 2;


	/* red platform */
      for(i=0; i<100; i++) {
         for(j=0; j<100; j++) {
            world[i][24][j] = 3;
         }
      }
	/* fill in world under platform - removed for assignment 3*/
/*
      for(i=0; i<100; i++) {
         for(j=0; j<100; j++) {
            for(k=0; k<24; k++) {
               world[i][k][j] = 3;
            }
         }
      }
*/
	/* blue box shows xy bounds of the world */
      for(i=0; i<99; i++) {
         world[0][25][i] = 2;
         world[i][25][0] = 2;
         world[99][25][i] = 2;
         world[i][25][99] = 2;
      }

	/* create two sample mobs */
      createMob(0, 50.0, 25.0, 52.0, 0.0);
      createMob(1, 50.0, 25.0, 52.0, 0.0);


   } else {

	/* your code to build the world goes here */

   }


	/* starts the graphics processing loop */
	/* code after this will not run until the program exits */
   glutMainLoop();
   return 0; 
}

