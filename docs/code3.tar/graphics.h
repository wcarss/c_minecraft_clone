
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#include <GLUT/glut.h>

        /* world size and storage array */
GLubyte  world[100][50][100];

#define MAX_DISPLAY_LIST 500000

